"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const crypto_1 = require("crypto");
const handler = async (event, _context) => {
    // Start processing date and time
    const now = new Date().toISOString();
    // Generate a new ID for the shipment
    const shipmentId = (0, crypto_1.randomUUID)();
    // Create the shipment
    const response = {
        shipmentId,
        status: "CREATED",
        createdAt: now,
        lastUpdatedAt: now,
        destinationCountry: event?.destinationCountry,
        orderId: event?.orderId,
    };
    // Return the response
    return response;
};
exports.handler = handler;
